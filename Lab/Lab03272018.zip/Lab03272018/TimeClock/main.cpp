/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on March 27th, 2018   10:20 AM
 * Purpose:  Nested Loops - Odometer
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <fstream>  //File Library
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    ofstream out;

    //Initial Variables
    out.open("TimeClock.out");
    
    //Map/Process Inputs to Outputs
    for(char tnhours='0';tnhours<='1';tnhours++){
        for(char hours='0';hours<='1';hours++){
            for(char tnminutes='0';tnminutes<='5';tnminutes++){
                for(char minutes='0';minutes<='9';minutes++){
                    for(char tnseconds='0';tnseconds<='5';tnseconds++){
                        for(char seconds='0';seconds<='9';seconds++){
 
                                
                            out<<tnhours
                                    <<hours<<":"
                                    <<tnminutes
                                    <<minutes<<":"
                                    <<tnseconds
                                    <<seconds<<endl;
                            
                        }
                    }  
                } 
            }
        }
    }

    //Close file
    out.close();
    cout<<"sup"<<endl;
    //Exit program!
    return 0;
}